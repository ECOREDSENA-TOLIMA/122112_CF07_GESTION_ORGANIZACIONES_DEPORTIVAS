<template lang="pug">
.curso-main-container.pb-3
  BannerInterno
  .container.tarjeta.tarjeta--blanca.p-4.p-md-5.mb-5
    .titulo-principal.color-acento-contenido
      .titulo-principal__numero(data-aos="fade-right")
        span 7
      h1(data-aos="fade-left") Cierre del evento 
    
    .bloque-texto-g.bloque-texto-g--inverso.p-3.p-sm-4.mb-5(style="background-color: #FE502D")
      .bloque-texto-g__img(
        :style="{'background-image': `url(${require('@/assets/curso/temas/tema7/img-1.jpg')})`}"
        style="background-repeat: no-repeat; background-position: right;"
      )
      .bloque-texto-g__texto.p-4(data-aos="fade-left")
        p.mb-0 El cierre del evento es muy importante para el éxito del mismo, por tanto, hay que tener una planificación igual que en las otras fases. Hay que realizarlo de modo que genere un gran impacto. El cierre oficial del evento o la ceremonia de clausura es un acto más informal. En el caso de los eventos deportivos, estas ceremonias se caracterizan por los grandes lazos de confraternidad entre los deportistas e integración entre las delegaciones. Estos son algunos pasos a desarrollar:

    h3(data-aos="fade-right") Ceremonias de premiación
    p.mb-5(data-aos="fade-right") es donde se realiza la premiación de los deportistas en cada disciplina o evento deportivo, esta ceremonia debe estar coordinada y desarrollada según el plan de acción del evento, teniendo en cuenta lo siguiente: 

    .d-flex.flex-wrap.mb-5
      .col-lg-8.pe-lg-4.mb-0
        ul.lista-ul--separador
          li.d-flex
            i.fas.fa-angle-right(style="color: #FE502D; font-size: 20px" data-aos="fade-right")
            p.mb-0 Determinar, según la instalación y el deporte, el sitio donde se llevará a efecto la premiación.
          li.d-flex
            i.fas.fa-angle-right(style="color: #FE502D; font-size: 20px" data-aos="fade-right")
            p.mb-0 Coordinar todo lo referente a las medallas, trofeos o diplomas que se vayan a entregar en la ceremonia.
          li.d-flex
            i.fas.fa-angle-right(style="color: #FE502D; font-size: 20px" data-aos="fade-right")
            p.mb-0 Definir las funciones del personal técnico y auxiliar.
          li.d-flex
            i.fas.fa-angle-right(style="color: #FE502D; font-size: 20px" data-aos="fade-right")
            p.mb-0 Coordinar todo lo referente al servicio de audio y con las músicas previstas (himnos, marchas).
          li.d-flex
            i.fas.fa-angle-right(style="color: #FE502D; font-size: 20px" data-aos="fade-right")
            p.mb-0 Prever el locutor del acto.
          li.d-flex
            i.fas.fa-angle-right(style="color: #FE502D; font-size: 20px" data-aos="fade-right")
            p.mb-0 Revisar todos los factores técnicos y medios básicos necesarios para la ceremonia.
          li.d-flex
            i.fas.fa-angle-right(style="color: #FE502D; font-size: 20px" data-aos="fade-right")
            p.mb-0 Determinar los estrados de premiación.
          li.d-flex
            i.fas.fa-angle-right(style="color: #FE502D; font-size: 20px" data-aos="fade-right")
            p.mb-0 Definir el podio de izamiento de banderas y otros medios.
          li.d-flex
            i.fas.fa-angle-right(style="color: #FE502D; font-size: 20px" data-aos="fade-right")
            p.mb-0 Seleccionar las banderas de los países y estados.
          li.d-flex
            i.fas.fa-angle-right(style="color: #FE502D; font-size: 20px" data-aos="fade-right")
            p.mb-0 Determinar el vestuario del personal de premiación.
          li.d-flex
            i.fas.fa-angle-right(style="color: #FE502D; font-size: 20px" data-aos="fade-right")
            p.mb-0 Establecer los medios de comunicación.
          li.d-flex
            i.fas.fa-angle-right(style="color: #FE502D; font-size: 20px" data-aos="fade-right")
            p.mb-0 Mantener una estrecha coordinación con la comisión del deporte para la localización y presentación de los atletas al área de premiación.
          li.d-flex
            i.fas.fa-angle-right(style="color: #FE502D; font-size: 20px" data-aos="fade-right")
            p.mb-0 Prever un lugar en la instalación para guardar todos los medios básicos necesarios para la ceremonia.
      img.col-lg-4.mx-auto.mb-4.mb-lg-auto(src="@/assets/curso/temas/tema7/img-2.png" style="max-width: 400px" data-aos="fade-left")

    p.mb-5(data-aos="fade-right") De acuerdo con lo anterior, a continuación, se relacionan los pasos para el cierre del evento:

    .d-flex.flex-wrap.align-items-center.mb-5
      img.col-lg-4.mx-auto.mb-4.mb-lg-auto(src="@/assets/curso/temas/tema7/img-3.png" style="max-width: 400px" data-aos="fade-right")
      .col-lg-8.ps-lg-4
        ul.lista-ul--separador
          li.d-flex
            i.fas.fa-angle-right(style="color: #FE502D; font-size: 20px" data-aos="fade-right")
            p.mb-0 Realizar una recopilación del evento, incluyendo los medios audiovisuales. Es importante celebrar los desafíos y centrarse en los éxitos.
          li.d-flex
            i.fas.fa-angle-right(style="color: #FE502D; font-size: 20px" data-aos="fade-right")
            p.mb-0 Agradecer a todos los que hicieron posible la realización del evento.
          li.d-flex
            i.fas.fa-angle-right(style="color: #FE502D; font-size: 20px" data-aos="fade-right")
            p.mb-0 Agradecer a los asistentes y participantes.
          li.d-flex
            i.fas.fa-angle-right(style="color: #FE502D; font-size: 20px" data-aos="fade-right")
            p.mb-0 Considerar discurso y palabras de personas representativas para el evento.
          li.d-flex
            i.fas.fa-angle-right(style="color: #FE502D; font-size: 20px" data-aos="fade-right")
            p.mb-0 Preparar un espectáculo cultural o artístico.

        .cajon.color-primario.p-4(style="background-color: #DFE5FF" data-aos="fade-left")
          p.mb-0 Es importante cumplir con el cronograma propuesto y con la misma disciplina de las diferentes fases, manteniendo el estado de alerta ante cualquier situación que se presente y resolverla lo más pronto posible.

      
</template>

<script>
export default {
  name: 'Tema3',
  data: () => ({
    // variables de vue
  }),
  mounted() {
    this.$nextTick(() => {
      this.$aosRefresh()
    })
  },
  updated() {
    this.$aosRefresh()
  },
}
</script>

<style lang="sass"></style>
