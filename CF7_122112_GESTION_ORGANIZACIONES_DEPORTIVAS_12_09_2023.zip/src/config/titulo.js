module.exports = 'Ejecución del evento'
